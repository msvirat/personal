import numpy as np
import pandas as pd
from flask import Flask, request, render_template, redirect, flash, url_for
from flask_mysqldb import MySQL
import MySQLdb.cursors


app = Flask(__name__)
app.secret_key = 'your secret key'


# Enter your database connection details below
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'Welcome@123'
app.config['MYSQL_DB'] = 'studentlogin'

# Intialize MySQL
mysql = MySQL(app)


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST':
        # Create variables for easy access
        name = request.form['name']
        collegeid = request.form['collegeid']
        email = request.form['email']
        mobile = request.form['mobile']
        password = request.form['password']
        #collegeid = request.form['collegeid']
        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM studentregister WHERE CollegeID = %s OR Email = %s', (collegeid, email,))
        # Fetch one record and return result
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            flash("Account already Exists", "warning")
            # Create session data, we can access this data in other routes
            return redirect(request.url)
        else:
            # Account doesnt exists and the form data is valid, now insert new account into accounts table
            cursor.execute('INSERT INTO studentregister VALUES (NULL, %s, %s, %s, %s, %s, %s)', (name, collegeid, email, mobile,password,'Pending',))
            mysql.connection.commit()
            flash("Account created!", "success")
            return redirect(request.url)
        return render_template('index.html')
    # Show the login form with message (if any)
    return render_template('index.html')



@app.route('/login', methods=['GET', 'POST'])
def login():
    # Output message if something goes wrong...
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST':
        # Create variables for easy access
        email = request.form['email']
        password = request.form['password']
        # Check if account exists using MySQL
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM studentregister WHERE Email = %s AND Password = %s', (email, password,))
        # Fetch one record and return result
        account = cursor.fetchone()
        # If account exists in accounts table in out database
        if account:
            cursor.execute('SELECT Status FROM studentregister WHERE Email = %s AND Password = %s', (email, password,))
            status = cursor.fetchone()
            status = list(status.values())[0]

            if status == 'Approved':
                cursor.execute('SELECT Name FROM studentregister WHERE Email = %s AND Password = %s',
                               (email, password,))
                name = cursor.fetchone()
                name = list(name.values())[0]
                flash("Successfully Logged In! Welcome "+ str(name), "success")

                return redirect(url_for('virtual'))
            else:
                flash('Your login was not approved. Please contact the administration.', "danger")
                return redirect(request.url)
        else:
            # Account doesnt exist or username/password incorrect
            flash("Incorrect username/password", "warning")
            return redirect(request.url)
    # Show the login form with message (if any)
    return render_template('login.html')



@app.route('/adminlogin', methods=['GET', 'POST'])
def adminlogin():
    # Output message if something goes wrong...
    # Check if "username" and "password" POST requests exist (user submitted form)
    if request.method == 'POST':
        if request.form['email'] == 'admin@college.com' and request.form['password'] == 'admin':
            flash("Successfully Logged In! Welcome Admin", "success")
            return redirect(url_for('adminhome'))
        else:
            # Account doesnt exist or username/password incorrect
            flash("Incorrect username/password", "warning")
            return redirect(request.url)
    # Show the login form with message (if any)
    return render_template('adminlogin.html')




@app.route('/adminhome', methods=['GET', 'POST'])
def adminhome():
    # Output message if something goes wrong...
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM studentregister WHERE Status = %s', ('Pending',))
    # Fetch one record and return result
    account = cursor.fetchall()
    if account:
        return render_template('adminhome.html', users=account)
    # Check if "username" and "password" POST requests exist (user submitted form)
    else:
        flash('No New Student Registration.', 'success')
        return render_template('adminhome.html')
    return render_template('adminhome.html')



@app.route('/accept/<CollegeID>', methods = ['GET', 'POST'])
def accept(CollegeID):
    print(CollegeID)
    print(type(CollegeID))
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('UPDATE studentlogin.studentregister SET Status = "Approved" WHERE CollegeID = %s', (CollegeID,))
    mysql.connection.commit()

    flash('User Request '+ str(CollegeID) +' is Approved', "success")
    return redirect(url_for('adminhome'))


@app.route('/delete/<CollegeID>', methods = ['GET', 'POST'])
def delete(CollegeID):
    print(CollegeID)
    print(type(CollegeID))
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('DELETE FROM studentlogin.studentregister WHERE CollegeID = %s', (CollegeID,))
    mysql.connection.commit()

    flash('User Request '+ str(CollegeID) +' is Rejected', "success")
    return redirect(url_for('adminhome'))




@app.route('/virtual', methods = ['GET', 'POST'])
def virtual():
    if request.method == 'POST':
        year = int(request.form['year'])
        semester = int(request.form['semester'])

        if year == 1 and (semester == 1 or 2):
            return redirect('https://www.programiz.com/c-programming/online-compiler/')
        elif year == 2 and (semester == 3 or 4):
            return redirect('https://www.programiz.com/cpp-programming/online-compiler/')
        elif year == 3 and (semester == 5 or 6):
            return redirect('https://www.programiz.com/python-programming/online-compiler/')
        elif year == 4 and (semester == 7 or 8):
            return redirect('https://www.programiz.com/java-programming/online-compiler/')

        else:

            flash("Please Select Correct Year and Semester", "warning")
            return redirect(request.url)

    return render_template('virtual.html')




if __name__ == "__main__":
    app.run(debug=True)

